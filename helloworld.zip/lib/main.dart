import 'dart:convert';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
      routes: {
        '/registration': (context) => RegistrationScreen(),
        '/image': (context) => ImageScreen(),
        '/welcome': (context) => WelcomeScreen(),
        '/activities': (context) => ActivitiesScreen(),
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      backgroundColor: Colors.lightGreen,
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, '/registration');
          },
          child: Text('Welcome to PSAU activities'),
        ),
      ),
    );
  }
}

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  List<Map<String, dynamic>> users = [];

  @override
  void initState() {
    super.initState();
    // Load users data from JSON
    String jsonData =
        '[{"username": "remaz", "password": "password1"}, {"username": "noura", "password": "password2"},{"username": "lena", "password": "password3"},{"username": "latifa", "password": "password4"}]';
    users = json.decode(jsonData).cast<Map<String, dynamic>>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registration'),
      ),
      backgroundColor: Colors.lightGreen,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Check if username and password are valid
                String enteredUsername = _usernameController.text;
                String enteredPassword = _passwordController.text;
                bool isValidUser = false;

                for (var user in users) {
                  if (user['username'] == enteredUsername &&
                      user['password'] == enteredPassword) {
                    isValidUser = true;
                    break;
                  }
                }

                if (isValidUser) {
                  Navigator.pushReplacementNamed(context, '/image');
                } else {
                  // Show error message or do something else
                  print('Invalid username or password!');
                }
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class ImageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome!'),
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'image/photo_2024-05-11_23-38-16.jpg',
              // Replace 'image/acc.jpg' with the path to your image asset
              width: 400,
              height: 400,
            ),
            SizedBox(height: 50),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/activities');
              },
              child: Text('Go to Activities'),
            ),
          ],
        ),
      ),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome'),
      ),
      body: Center(
        child: Text(
          'Welcome to PSAU activity!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

class ActivitiesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('The Activities'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Data Science Event',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'STC Hackathon',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'National Day Event',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
